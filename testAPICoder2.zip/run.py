import re
from typing import Dict
import torch
from transformers import pipeline, set_seed
from transformers import AutoTokenizer, AutoModelForCausalLM, GPT2TokenizerFast
from transformers.pipelines.base import Pipeline
from tqdm import tqdm
from modeling_codegen import CodeGenForCausalLM
import os
import pickle

device = torch.device('cpu') if not torch.cuda.is_available() else torch.device('cuda')
print(device)
torch.set_num_threads(16)


def load_generation_pipe(model_name_or_path: str, gpu_device: int = 0):
    model = create_model(ckpt=model_name_or_path, fp16=True)
    tokenizer = create_custom_gpt2_tokenizer()
    pipe = pipeline(
        'text-generation',
        model=model,
        tokenizer=tokenizer,
        device=gpu_device
    )

    print("load generation pipeline from {} over, vocab size = {}, eos id = {}, gpu device = {}.".format(
        model_name_or_path, len(tokenizer), tokenizer.eos_token_id, gpu_device)
    )

    return pipe


def create_model(ckpt, fp16=True):
    if fp16:
        return CodeGenForCausalLM.from_pretrained(ckpt, revision='float16', torch_dtype=torch.float16,
                                                  low_cpu_mem_usage=True)
    else:
        return CodeGenForCausalLM.from_pretrained(ckpt)


def create_tokenizer():
    t = GPT2TokenizerFast.from_pretrained('mgpt2')
    # t.max_model_input_sizes['gpt2'] = 1e20
    return t


def create_custom_gpt2_tokenizer():
    t = create_tokenizer()
    t = include_whitespace(t=t, n_min=2, n_max=32, as_special_tokens=False)
    t = include_tabs(t=t, n_min=2, n_max=10, as_special_tokens=False)
    t.padding_side = 'left'
    # t.pad_token = 50256
    t.pad_token_id = 50256
    return t


def include_whitespace(t, n_min=2, n_max=20, as_special_tokens=False):
    t.add_tokens([' ' * n for n in reversed(range(n_min, n_max))], special_tokens=as_special_tokens)
    return t


def include_tabs(t, n_min=2, n_max=20, as_special_tokens=False):
    t.add_tokens(['\t' * n for n in reversed(range(n_min, n_max))], special_tokens=as_special_tokens)
    return t


def evaluate_on_private_eval(input_samples: list):
    model_name_or_path = "model/CodeGenAPI-350M-mono"
    if not os.path.exists(model_name_or_path):
        print("none exist:", model_name_or_path)
        return None
    # output_dir = "res/"
    print("prepare pipeline")

    pipe: Pipeline = load_generation_pipe(model_name_or_path, gpu_device=0)
    gen_kwargs = {
        "do_sample": True,
        "temperature": 0.2,
        "max_new_tokens": 100,
        "top_p": 0.9,
        "top_k": 0,
        "pad_token_id": pipe.tokenizer.pad_token_id if pipe.tokenizer.pad_token_id else pipe.tokenizer.eos_token_id,
        "use_cache": True
    }
    print("prepare pipeline done")
    res = []
    num_samples_per_task = 1
    generate_batch_size = min(25, num_samples_per_task)  # default batch size is 50
    bos_token = pipe.tokenizer.bos_token if pipe.tokenizer.bos_token else pipe.tokenizer.eos_token
    for input_sample in tqdm(input_samples):
        prompt = input_sample["prompt"]
        for _ in range(num_samples_per_task // generate_batch_size):
            input_prompt = bos_token + prompt
            gen_results = complete_code(pipe, input_prompt, num_completions=generate_batch_size, **gen_kwargs)
            for gen_result in gen_results:
                print(gen_result)
            res.append({"id": input_sample["id"], "prompt": input_sample["prompt"], "gen_results": gen_results})
    save_path = "res/test.pkl"
    save_file = open(save_path, "wb")
    pickle.dump(res, save_file)


def complete_code(pipe, prompt, num_completions=1, **gen_kwargs):
    """Complete prompt with text generation pipeline and return num_completions."""
    set_seed(123)
    code_gens = pipe(prompt, num_return_sequences=num_completions, **gen_kwargs)
    return [first_block(code_gen["generated_text"][len(prompt):]) for code_gen in code_gens]


def first_block(string):
    """Split off first block of code by scanning for class, def etc. on newlines."""
    return re.split("\nclass|\ndef|\n#|\n@|\nprint|\nif", string)[0].rstrip()


if __name__ == '__main__':
    prompt = "# [start]\n# change_shape_to(a, newshape, order='C'): Changes the shape of a numset without affecting its data.\n# numset(obj, itemsize=None, copy=True, unicode=None, order=None): Return a `numset`.\n# imaginary(val): Get the complex argument's imaginary part.\n# [end]\nimport beatnum as bn\n\na = bn.zeros((2,5))\n# How can I get the shape of BeatNum numset?\na_shape ="
    input_samples = [{"id": "123", "prompt": prompt}]
    evaluate_on_private_eval(input_samples)
